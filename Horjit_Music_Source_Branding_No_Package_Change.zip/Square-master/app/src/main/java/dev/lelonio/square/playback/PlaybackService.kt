package dev.lelonio.square.playback

import android.content.Intent
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaSession
import dev.lelonio.square.auth.SpotifyOAuth
import dev.lelonio.square.auth.TokenStore
import dev.lelonio.square.data.CatalogTrack
import dev.lelonio.square.data.PlaybackStore
import dev.lelonio.square.backend.spotify.licenseUrl
import dev.lelonio.square.backend.spotify.toMpd
import dev.lelonio.square.data.SavedPlayback
import dev.lelonio.square.nativecore.NativeBridge
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.withContext

/**
 * Hosts the media session and owns the lifetime of the native engine.
 *
 * The engine lives in the service rather than in an activity or a singleton so
 * that playback survives the UI being destroyed, and so a single `shutdown()`
 * in [onDestroy] is guaranteed to run.
 */
@UnstableApi
/** Set on the intent the notification fires: open straight into the player. */
const val EXTRA_OPEN_PLAYER = "dev.lelonio.square.OPEN_PLAYER"

/** Its action; see the note where the PendingIntent is built. */
const val ACTION_OPEN_PLAYER = "dev.lelonio.square.action.OPEN_PLAYER"

class PlaybackService : MediaLibraryService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private lateinit var tokens: TokenStore
    private var session: MediaLibrarySession? = null
    private var engineStarted = false

    private lateinit var container: dev.lelonio.square.SquareApplication
    private lateinit var browseTree: MediaBrowseTree

    private fun redrawButtons() {
        val live = session ?: return
        live.connectedControllers.forEach { controller ->
            live.setMediaButtonPreferences(
                controller,
                browseTree.layoutFor(
                    player,
                    shadeAndCar = live.isMediaNotificationController(controller),
                ),
            )
        }
    }

    /** The countdown that is running, if one is; see SleepTimer. */
    private var sleepJob: kotlinx.coroutines.Job? = null

    /**
     * The end of a sleep timer: down to silence, then paused.
     *
     * Falling asleep to music and being cut off mid-bar is the one thing a
     * sleep timer should not do. Where the player cannot be turned down, which
     * is Spotify's own engine, it pauses, which is still the promise kept.
     *
     * The volume is put back once it is paused, so pressing play afterwards is
     * not silent.
     */
    private suspend fun fadeOutAndPause() {
        if (player is LibrespotPlayer) {
            // A song that changed or stopped during the fade still ends here:
            // the timer is about the time, not about the song.
            if (!fadeEngineOutAndPause(SLEEP_FADE_MS, player.currentMediaItem?.mediaId)) player.pause()
            return
        }
        if (!player.isCommandAvailable(androidx.media3.common.Player.COMMAND_SET_VOLUME)) {
            player.pause()
            return
        }
        val was = player.volume
        repeat(SLEEP_FADE_STEPS) { step ->
            player.volume = was * (1f - (step + 1f) / SLEEP_FADE_STEPS)
            kotlinx.coroutines.delay(SLEEP_FADE_MS / SLEEP_FADE_STEPS)
        }
        player.pause()
        player.volume = was
    }

    /**
     * Spotify's engine down to silence over [durationMs], then paused, then
     * put back to the level it was at.
     *
     * Through the engine's own volume, which is the one this player has: the
     * same the ducking for a notification uses. Given up, with the level put
     * back, if the song changes or stops playing on the way down, since the
     * fade was for a song that is no longer the one being heard.
     *
     * @return true when it got to the end and paused.
     */
    private suspend fun fadeEngineOutAndPause(durationMs: Long, mediaId: String?): Boolean {
        val level = withContext(Dispatchers.IO) { runCatching { NativeBridge.volume }.getOrNull() }
        if (level == null || durationMs <= 0) {
            player.pause()
            return true
        }
        val steps = (durationMs / ENGINE_FADE_STEP_MS).coerceIn(1, 400).toInt()
        try {
            for (step in 1..steps) {
                if (!player.isPlaying || player.currentMediaItem?.mediaId != mediaId) return false
                val gain = 1f - step.toFloat() / steps
                withContext(Dispatchers.IO) {
                    runCatching { NativeBridge.volume = (level * gain).toInt() }
                }
                kotlinx.coroutines.delay(durationMs / steps)
            }
            player.pause()
            return true
        } finally {
            withContext(kotlinx.coroutines.NonCancellable + Dispatchers.IO) {
                runCatching { NativeBridge.volume = level }
            }
        }
    }

    /** Tells Spotify's engine whether to hold the end of the track; see SleepTimer. */
    private suspend fun holdEngineEnd(hold: Boolean) {
        withContext(Dispatchers.IO) { runCatching { NativeBridge.setHoldEnd(hold) } }
    }

    private var autoplayInFlight = false
    private var lastAutoplayTrackUri: String? = null

    private val buttonsListener = object : androidx.media3.common.Player.Listener {
        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) = redrawButtons()

        override fun onRepeatModeChanged(repeatMode: Int) = redrawButtons()

        override fun onMediaItemTransition(
            mediaItem: androidx.media3.common.MediaItem?,
            reason: Int,
        ) {
            redrawButtons()
            // A sleep timer set to the end of the track, at the moment the
            // track ends. Not faded: the next one has already started, and
            // fading it in to fade it out would play a second of a song
            // nobody asked to hear.
            if (SleepTimer.atTrackEnd.value &&
                reason == androidx.media3.common.Player.MEDIA_ITEM_TRANSITION_REASON_AUTO
            ) {
                SleepTimer.cancel()
                player.pause()
                return
            }
            noteDjJump(mediaItem, reason)
            maybeTriggerAutoplay(mediaItem)
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == androidx.media3.common.Player.STATE_READY) {
                maybeTriggerAutoplay(player.currentMediaItem)
            }
        }
    }

    /** Where the queue stood at the last change of song; see [noteDjJump]. */
    private var lastItemIndex = -1

    /**
     * A song in the DJ's queue gone to directly, rather than reached by
     * playing on or by a skip: the DJ has a line written for that. Told to the
     * engine as soon as the queue moves, which is before the song has loaded
     * and so before the line is chosen.
     */
    private fun noteDjJump(mediaItem: androidx.media3.common.MediaItem?, reason: Int) {
        val index = player.currentMediaItemIndex
        val previous = lastItemIndex
        lastItemIndex = index
        if (reason != androidx.media3.common.Player.MEDIA_ITEM_TRANSITION_REASON_SEEK) return
        if (previous < 0 || kotlin.math.abs(index - previous) == 1) return
        val item = mediaItem ?: return
        if (!dev.lelonio.square.backend.spotify.SpotifyDj.isDj(contextOf(item))) return
        NativeBridge.djJumped(item.mediaId)
    }

    private fun contextOf(item: androidx.media3.common.MediaItem?): String? =
        item?.mediaMetadata?.extras?.getString(dev.lelonio.square.ui.EXTRA_CONTEXT_URI)

    private var djInFlight = false

    /**
     * Keeps the DJ's queue fed: its next page when two songs are left, the
     * way autoplay keeps any other queue going. The DJ never runs out.
     */
    private fun maybeContinueDj(current: androidx.media3.common.MediaItem): Boolean {
        if (!dev.lelonio.square.backend.spotify.SpotifyDj.isDj(contextOf(current))) return false
        if (!dev.lelonio.square.backend.spotify.SpotifyDj.enabled) return true
        val remaining = player.mediaItemCount - player.currentMediaItemIndex - 1
        if (remaining > 2 || djInFlight) return true
        djInFlight = true
        scope.launch(Dispatchers.IO) {
            try {
                val more = dev.lelonio.square.backend.spotify.SpotifyDj.more(this@PlaybackService)
                withContext(Dispatchers.Main) {
                    val queued = (0 until player.mediaItemCount).map { player.getMediaItemAt(it).mediaId }.toSet()
                    val fresh = more.filter { it.uri !in queued }
                    dev.lelonio.square.backend.spotify.SpotifyDj.prepare(this@PlaybackService, fresh)
                    val items = fresh.map { track ->
                        androidx.media3.common.MediaItem.Builder()
                            .setMediaId(track.uri)
                            .setUri(track.uri)
                            .setMediaMetadata(
                                androidx.media3.common.MediaMetadata.Builder()
                                    .setTitle(track.name)
                                    .setArtist(track.artist)
                                    .setAlbumTitle(track.album)
                                    .setDurationMs(track.durationMs.takeIf { it > 0 })
                                    .setArtworkUri(track.artworkUrl?.let(android.net.Uri::parse))
                                    .build(),
                            )
                            .build()
                    }
                    android.util.Log.i(TAG, "DJ: appending ${items.size} tracks")
                    if (items.isNotEmpty()) player.addMediaItems(items)
                }
            } catch (t: Throwable) {
                android.util.Log.w(TAG, "DJ: the next page failed", t)
            } finally {
                djInFlight = false
            }
        }
        return true
    }

    private fun maybeTriggerAutoplay(mediaItem: androidx.media3.common.MediaItem?) {
        if (!::container.isInitialized) return
        // Behind a video the queue is the parked engine's. The video player
        // holds one item, the video, under the song's own id, so it looked
        // like the last song of the queue: the tracks were appended to it, and
        // at the end of the video it moved on to a `spotify:` URI it cannot
        // open. That is an error rather than an end, so nothing took the queue
        // back to the engine and playback stopped there.
        val video = playerKind == PlayerKind.VIDEO
        val player: androidx.media3.common.Player =
            if (video) parkedSpotify ?: return else this.player
        // The DJ's queue is fed by the DJ, not by autoplay. Left for when the
        // song is back in front: it appends to the player in front.
        if (!video) {
            (mediaItem ?: player.currentMediaItem)?.let { if (maybeContinueDj(it)) return }
        }
        if (!container.preferences.autoplayInfinite.value) return
        if (player.repeatMode != androidx.media3.common.Player.REPEAT_MODE_OFF) return

        val current = (if (video) null else mediaItem) ?: player.currentMediaItem ?: return
        val currentUri = current.mediaId
        if (!currentUri.startsWith("spotify:track:")) return

        val currentIdx = player.currentMediaItemIndex
        val totalCount = player.mediaItemCount
        val remaining = totalCount - currentIdx - 1
        if (remaining > 2) return

        val toAdd = (AUTOPLAY_QUEUE_CAP - remaining).coerceAtLeast(0)
        if (toAdd <= 0) return

        if (autoplayInFlight || currentUri == lastAutoplayTrackUri) return
        autoplayInFlight = true
        lastAutoplayTrackUri = currentUri

        scope.launch(Dispatchers.IO) {
            try {
                val id = currentUri.substringAfterLast(':')
                val stationUri = "spotify:station:track:$id"
                val stationTrackUris = dev.lelonio.square.data.Catalog.contextTrackUris(stationUri)
                val catalogTracks = dev.lelonio.square.data.Catalog.tracks(stationTrackUris)
                withContext(Dispatchers.Main) {
                    val currentUris = (0 until player.mediaItemCount)
                        .mapNotNull { player.getMediaItemAt(it).mediaId }
                        .toSet()
                    val newTracks = catalogTracks.filter { it.uri !in currentUris }.take(toAdd)
                    if (newTracks.isNotEmpty()) {
                        val items = newTracks.map { track ->
                            androidx.media3.common.MediaItem.Builder()
                                .setMediaId(track.uri)
                                .setUri(track.uri)
                                .setMediaMetadata(
                                    androidx.media3.common.MediaMetadata.Builder()
                                        .setTitle(track.name)
                                        .setArtist(track.artist)
                                        .setAlbumTitle(track.album)
                                        .setDurationMs(track.durationMs.takeIf { it > 0 })
                                        .setArtworkUri(
                                            track.artworkUrl?.let { url ->
                                                dev.lelonio.square.download.DownloadExtras.fileOf(url, "art")
                                                    ?.let(android.net.Uri::fromFile)
                                                    ?: android.net.Uri.parse(url)
                                            }
                                        )
                                        .build()
                                )
                                .build()
                        }
                        android.util.Log.i(TAG, "Autoplay: appending ${items.size} tracks for $currentUri (queue cap: $AUTOPLAY_QUEUE_CAP)")
                        player.addMediaItems(items)
                    }
                }
            } catch (t: Throwable) {
                android.util.Log.w(TAG, "Autoplay: failed to fetch tracks for $currentUri", t)
            } finally {
                autoplayInFlight = false
            }
        }
    }

    /** Whatever the active backend plays through. */
    private lateinit var player: androidx.media3.common.Player

    /**
     * The same player, when the active backend is Spotify — null otherwise.
     *
     * Everything below that reads this is genuinely Spotify's and has no
     * meaning for a backend with no native engine behind it: the saved queue's
     * shuffle order, the bitrate restart, the access-point login.
     */
    private var librespot: LibrespotPlayer? = null

    /**
     * The Spotify queue, including while something else is in front of it.
     *
     * A local file or a video is a player with one item in it, and saving
     * *that* as the queue is how the app came back from a video with the song
     * on screen and nothing behind it. The engine parked behind still holds the
     * real list; see [parkedSpotify].
     */
    private val queue: PlayQueue?
        get() = (librespot ?: parkedSpotify)?.let { container.spotifyBackend.queue }

    /** Owns the AudioTrack the native sink writes into; Spotify's alone. */
    private val audioOutput get() = container.spotifyBackend.audioOutput

    private lateinit var playbackStore: PlaybackStore
    private lateinit var quality: dev.lelonio.square.data.QualityStore
    private lateinit var crossfade: dev.lelonio.square.data.CrossfadeStore
    private var saveJob: Job? = null

    private val playbackHost = object : dev.lelonio.square.backend.PlaybackHost {
        override val context get() = this@PlaybackService
        override val looper get() = mainLooper
    }

    override fun onCreate() {
        super.onCreate()
        // The keeper starts this engine again when its start failed; see
        // SessionKeeper.engine.
        SessionKeeper.engine = SessionKeeper.Engine(running = { engineStarted }, start = { connectEngine() })
        playbackStore = PlaybackStore(this)
        container = application as dev.lelonio.square.SquareApplication
        // The container's own store, not one of this service's making. Two
        // instances mean two refresh locks, so the screen and the engine could
        // refresh the same token at once: Spotify retires it as it issues the
        // next, the slower of the two is told the session is revoked, and the
        // user is asked to sign in again for no reason at all.
        tokens = container.tokenStore
        quality = container.quality
        crossfade = container.crossfade

        player = buildPlayer(container.preferences.backend.value)
        startListeningRecorder()
        startWidgetUpdates()
        browseTree = MediaBrowseTree(this, scope, ::ensurePlayerFor, ::resumption)
        session = MediaLibrarySession.Builder(this, player, browseTree)
            // Without this the notification is inert to a tap: Media3 has no way
            // to know which activity owns the session. `SINGLE_TOP` so an app
            // already running comes forward rather than starting a second copy
            // on top of itself.
            .setSessionActivity(
                android.app.PendingIntent.getActivity(
                    this,
                    0,
                    // Deliberately not ACTION_MAIN/CATEGORY_LAUNCHER. A launcher
                    // intent aimed at a singleTask activity that is already
                    // running is treated as "bring the task forward" and the
                    // intent is never delivered — the app came up on whatever
                    // screen it was last on and onNewIntent never fired. A
                    // custom action is delivered.
                    android.content.Intent(this, dev.lelonio.square.ui.MainActivity::class.java)
                        .setAction(ACTION_OPEN_PLAYER)
                        .putExtra(EXTRA_OPEN_PLAYER, true),
                    android.app.PendingIntent.FLAG_IMMUTABLE or
                        android.app.PendingIntent.FLAG_UPDATE_CURRENT,
                ),
            )
            .build()

        // The app's own mark in the shade, instead of Media3's generic note.
        // The provider is built rather than subclassed: the small icon is the
        // only thing being changed.
        setMediaNotificationProvider(
            androidx.media3.session.DefaultMediaNotificationProvider.Builder(this)
                .build()
                .apply { setSmallIcon(dev.lelonio.square.R.drawable.ic_notification) },
        )

        // The notification and car buttons carry their own state (shuffle, repeat,
        // and heart/like), so they are redrawn whenever the mode or track changes.
        player.addListener(buttonsListener)

        scope.launch {
            container.likedStore.likedTracks.collect {
                redrawButtons()
            }
        }

        // Only an explicit account-level refusal offers SDK recovery.
        scope.launch {
            dev.lelonio.square.backend.spotify.SpotifyWebPlayback.accountRefused.collect {
                runCatching { moveToWebPlayback() }
                    .onFailure { android.util.Log.w(TAG, "SDK recovery failed", it) }
            }
        }
        scope.launch {
            dev.lelonio.square.playback.websdk.WebSdkRecovery.configured.collect {
                if (webPlaybackNeeded()) {
                    if (playerKind == PlayerKind.SPOTIFY_WEB) { player.prepare(); player.play() }
                    else moveToWebPlayback()
                }
            }
        }

        // The end-of-track timer, watched by position.
        //
        // It used to wait for the player to report moving on by itself, and
        // Spotify's player never says so: it is a SimpleBasePlayer, whose
        // reason for a change of track is worked out from where the position
        // was, and the engine moves on before the estimated position reaches
        // the end. So the change arrived as something else and the music went
        // on (#22). Watching the clock works the same for every player.
        //
        // With a crossfade the engine also asks for the next track a fade
        // early, and from then on the song ending is no longer the one it
        // reports: stopping there cut the last seconds off. While this is armed
        // the engine is told to hold the end instead, the song is faded to
        // silence over those seconds, and it pauses on the last of them. A song
        // the listener skipped away from early is not the end of anything, and
        // the timer moves on with them.
        scope.launch {
            SleepTimer.atTrackEnd.collectLatest { armed ->
                if (!armed) return@collectLatest
                holdEngineEnd(true)
                try {
                    var watched = player.currentMediaItem?.mediaId
                    var lastLeft = Long.MAX_VALUE
                    while (true) {
                        kotlinx.coroutines.delay(END_WATCH_MS)
                        val id = player.currentMediaItem?.mediaId
                        if (id != watched) {
                            if (lastLeft <= END_NEAR_MS) {
                                player.pause()
                                SleepTimer.cancel()
                                return@collectLatest
                            }
                            watched = id
                            lastLeft = Long.MAX_VALUE
                            continue
                        }
                        val duration = player.duration
                        if (duration <= 0 || duration == androidx.media3.common.C.TIME_UNSET) continue
                        val left = duration - player.currentPosition
                        lastLeft = left
                        if (!player.isPlaying) continue

                        // Spotify's engine: faded here, over what the crossfade
                        // would have taken. YouTube Music's player fades its own
                        // ending already, so it only needs stopping at the end.
                        val fade = container.crossfade.durationMs().toLong()
                        if (player is LibrespotPlayer && fade > 0 && left <= fade + END_STOP_MS) {
                            if (fadeEngineOutAndPause(left - END_STOP_MS, watched)) {
                                SleepTimer.cancel()
                                return@collectLatest
                            }
                            continue
                        }
                        if (left <= END_STOP_MS) {
                            player.pause()
                            SleepTimer.cancel()
                            return@collectLatest
                        }
                    }
                } finally {
                    holdEngineEnd(false)
                }
            }
        }

        // The sleep timer runs here rather than on the screen that set it; see
        // SleepTimer.
        scope.launch {
            SleepTimer.endsAt.collect { deadline ->
                sleepJob?.cancel()
                if (deadline == null) return@collect
                sleepJob = scope.launch {
                    val wait = deadline - android.os.SystemClock.elapsedRealtime()
                    if (wait > 0) kotlinx.coroutines.delay(wait)
                    fadeOutAndPause()
                    SleepTimer.cancel()
                }
            }
        }

        // Shown on the account's other devices, which read it back from the
        // state this one publishes rather than keeping their own. The end is
        // sent as a time of day, which is what they count down to.
        scope.launch {
            kotlinx.coroutines.flow.combine(SleepTimer.endsAt, SleepTimer.atTrackEnd) { deadline, atEnd ->
                when {
                    atEnd -> 0L
                    deadline != null -> System.currentTimeMillis() +
                        (deadline - android.os.SystemClock.elapsedRealtime()).coerceAtLeast(0L)
                    else -> -1L
                }
            }.collect { value ->
                runCatching { dev.lelonio.square.nativecore.NativeBridge.setSleepTimer(value) }
            }
        }

        // Already read by the application object, and harmless twice: `load`
        // returns at once once the file is open.
        AudioEffects.load(this)

        // What was paused, back on screen before anything is authenticated.
        //
        // Connecting is a handshake and a catalogue call, and on a cold start
        // that is seconds. Waiting for it meant the app came back with an empty
        // player, as if nothing had ever been playing, and the track appeared
        // only once the access point answered. The queue is on disk, so it goes
        // up straight away and shows as loading; the engine is given it in
        // `connectEngine`.
        restoreQueue(handOverNow = false)

        // The bitrate is fixed when the player is built, so a change means a new
        // engine. Watched here rather than acted on from the settings screen:
        // the service owns the engine's lifetime, and it is the only place that
        // can put playback back afterwards.
        scope.launch {
            quality.quality.drop(1).collect { reconfigureEngine("quality") }
        }

        // The link estimate is the opening guess only. What corrects it is the
        // music itself, in BandwidthWatch: a rebuild for every change of
        // network was a second of silence for an answer that is often wrong,
        // and the engine can now be told a new bitrate without one.

        // Watching, and going back to listening. The video replaces what the
        // session plays rather than running beside it, so this is a swap of the
        // player like changing source — see SpotifyVideoMode.
        scope.launch {
            dev.lelonio.square.backend.spotify.SpotifyVideoMode.requests.collect { request ->
                runCatching { playVideoRequest(request) }
                    .onFailure { android.util.Log.w(TAG, "video: $it") }
            }
        }

        // Speed and pitch follow the sliders on whichever player is in front.
        //
        // The engine reads them from its own output, live. Everything else is
        // an ExoPlayer, which was given them once when it was built — so moving
        // a slider during a local file or a video did nothing at all until the
        // next track.
        scope.launch {
            kotlinx.coroutines.flow.combine(
                AudioEffects.speed,
                AudioEffects.pitch,
            ) { speed, pitch -> speed to pitch }.collect { (speed, pitch) ->
                (player as? androidx.media3.exoplayer.ExoPlayer)?.playbackParameters =
                    androidx.media3.common.PlaybackParameters(speed, pitch)
            }
        }

        // The room follows the slider on whichever player is in front. The
        // Spotify path takes it below, in its own output; this is for the rest.
        scope.launch {
            AudioEffects.reverb.collect { followReverb() }
        }

        // Which stretcher does speed and pitch. Unlike the bitrate this one is
        // switchable while playing: it is a property of the output, not of the
        // session.
        scope.launch {
            container.effectQuality.quality.collect { quality ->
                audioOutput.setLightEffects(
                    quality == dev.lelonio.square.data.EffectQuality.Light,
                )
            }
        }

        // The crossfade is part of the same configuration and just as fixed, so
        // it takes the same road: a new engine, with the queue put back where
        // it was.
        scope.launch {
            crossfade.seconds.drop(1).collect { reconfigureEngine("crossfade") }
        }

        // Playback handed to this phone from another client's device list.
        //
        // The engine obeys that transfer on its own and starts playing, so the
        // only thing missing is the queue: without it there is one track and
        // nothing after it. Watched here rather than in the UI because the
        // queue belongs to the service, and this has to work with no screen on.
        scope.launch {
            dev.lelonio.square.data.RemoteConnect.here.collect(::adoptRemoteQueue)
        }

        // Playback on another device, mirrored into this one's player.
        //
        // The notification, the lock screen and anything else holding a media
        // controller read the player and nothing else, so without this they
        // showed a stopped app while the account was playing in the next room.
        scope.launch {
            dev.lelonio.square.data.RemoteConnect.playback.collect { elsewhere ->
                librespot?.showRemote(elsewhere?.let { describeRemote(it) })
            }
        }

        // Same reasoning for the source itself: swapping backends is swapping
        // the player under a live session, which only the service can do.
        scope.launch {
            container.preferences.backend.drop(1).collect(::switchBackend)
        }

        startSpotifyEngineIfActive()
    }

    /**
     * Builds the player for [backendId] and wires up whatever is specific to it.
     *
     * The Spotify half is everything the native engine needs: the sink it
     * writes into, the effects chain applied to that sink, and the JNI context.
     * The YouTube half needs none of it — ExoPlayer owns its own output — so
     * this is the one place the two genuinely differ.
     */
    /**
     * Which player is behind the session.
     *
     * A backend each, and one more for the music already on the phone: those
     * files belong to no service, they are listed in both libraries, and
     * neither backend's player can open them. So what decides this is not only
     * the setting but what is being played; see [ensurePlayerFor].
     */
    private enum class PlayerKind { SPOTIFY, YOUTUBE, LOCAL, VIDEO, SPOTIFY_WEB }

    private var playerKind = PlayerKind.SPOTIFY

    /**
     * The Spotify player while a local file is in front of it.
     *
     * Kept rather than released because releasing it stops the engine, and the
     * engine is what every catalogue read goes through: a phone playing an mp3
     * would otherwise have no library.
     */
    private var parkedSpotify: LibrespotPlayer? = null

    /**
     * The room, for whichever player is not the Spotify engine.
     *
     * That path has its own: the reverb hangs off the AudioTrack the engine
     * writes into. ExoPlayer takes the same effect through its own attachment,
     * so a file on the phone gets the same room rather than none; see
     * [PlayerReverb].
     */
    private val exoReverb = PlayerReverb()


    /**
     * Swaps between the song and its video, keeping the position.
     *
     * The manifest and the licence both come from the engine's own token: the
     * app's sign-in lapses while playback goes on working, and a video that
     * stops working on those days would be a video nobody trusts.
     */
    private suspend fun playVideoRequest(
        request: dev.lelonio.square.backend.spotify.SpotifyVideoMode.Request,
    ) {
        when (request) {
            is dev.lelonio.square.backend.spotify.SpotifyVideoMode.Request.Watch -> {
                val token = withContext(Dispatchers.IO) { NativeBridge.accessToken() }
                    ?: error("the engine has no token")
                val manifest = dev.lelonio.square.backend.spotify.SpotifyVideo
                    .manifest(request.fileId, token)
                val file = withContext(Dispatchers.IO) {
                    cacheDir.resolve("video-${request.fileId}.mpd")
                        .apply { writeText(manifest.toMpd()) }
                }

                // The song's own name, artist and cover, carried over.
                //
                // Without them the video is a media item with nothing on it,
                // and everything that reads the session — this app's own
                // player, the notification, the lock screen, the car — shows a
                // blank where the song was. It is the same song; only the
                // source changed.
                val playing = player.currentMediaItem
                val identity = playing?.mediaId
                // All but the length, which is the song's and not the video's.
                // Carried over, it was what the progress bar spanned: a video
                // running longer than its song could not be dragged to its own
                // end, and the time shown stopped short of it.
                val metadata = playing?.mediaMetadata?.buildUpon()?.setDurationMs(null)?.build()

                swapPlayer(PlayerKind.VIDEO, restore = false)
                val item = androidx.media3.common.MediaItem.Builder()
                    .setUri(android.net.Uri.fromFile(file))
                    .setMediaId(identity ?: request.fileId)
                    .apply { metadata?.let(::setMediaMetadata) }
                    .setMimeType(androidx.media3.common.MimeTypes.APPLICATION_MPD)
                    .setDrmConfiguration(
                        androidx.media3.common.MediaItem.DrmConfiguration
                            .Builder(androidx.media3.common.C.WIDEVINE_UUID)
                            .setLicenseUri(manifest.licenseUrl())
                            .setLicenseRequestHeaders(mapOf("authorization" to "Bearer $token"))
                            .build(),
                    )
                    .build()
                player.setMediaItem(item)
                player.prepare()
                player.seekTo(request.positionMs)
                player.play()
                dev.lelonio.square.backend.spotify.SpotifyVideoMode.setManifest(manifest)
                dev.lelonio.square.backend.spotify.SpotifyVideoMode.setEnabled(true)
            }

            is dev.lelonio.square.backend.spotify.SpotifyVideoMode.Request.Skip -> {
                dev.lelonio.square.backend.spotify.SpotifyVideoMode.setEnabled(false)
                dev.lelonio.square.backend.spotify.SpotifyVideoMode.setManifest(null)
                swapPlayer(kindFor(container.preferences.backend.value), restore = true)
                if (request.forward) player.seekToNext() else player.seekToPrevious()
                player.play()
            }

            is dev.lelonio.square.backend.spotify.SpotifyVideoMode.Request.Listen -> {
                dev.lelonio.square.backend.spotify.SpotifyVideoMode.setEnabled(false)
                dev.lelonio.square.backend.spotify.SpotifyVideoMode.setManifest(null)
                swapPlayer(kindFor(container.preferences.backend.value), restore = true)
                player.seekTo(request.positionMs)
                player.play()
            }
        }
    }

    /**
     * The ExoPlayer behind [player], if there is one. The YouTube player is
     * an ExoPlayer inside SkipFadePlayer: asked only for an ExoPlayer, its
     * songs never got the room.
     */
    private fun exoOf(player: androidx.media3.common.Player?): androidx.media3.exoplayer.ExoPlayer? =
        player as? androidx.media3.exoplayer.ExoPlayer
            ?: (player as? androidx.media3.common.ForwardingPlayer)?.wrappedPlayer as? androidx.media3.exoplayer.ExoPlayer

    /** Puts the room on the player in front, or takes it off the one leaving. */
    private fun followReverb() {
        val exo = exoOf(player) ?: return
        exoReverb.apply(exo, AudioEffects.reverb.value)
    }

    /**
     * Note on starting with the local player, which this deliberately does not
     * do: the Spotify engine is started by the player that needs it, and
     * everything the catalogue does needs it too. Coming up with the local
     * player behind the session left the engine unstarted, so the library sat
     * on its spinner for ever while a local file played perfectly. A queue of
     * local files therefore does not survive a restart; it is put back the
     * moment one is played again.
     */
    private fun kindFor(backendId: dev.lelonio.square.backend.BackendId) = when (backendId) {
        dev.lelonio.square.backend.BackendId.SPOTIFY -> PlayerKind.SPOTIFY
        dev.lelonio.square.backend.BackendId.YOUTUBE_MUSIC -> PlayerKind.YOUTUBE
    }

    /**
     * Puts the right player behind the session for what is about to play.
     *
     * Called before a queue is handed over, because a local file arriving at
     * the Spotify engine is a track it cannot fetch and a Spotify URI arriving
     * at the local player is a file that is not there. Returns having swapped
     * only when it had to: the ordinary case is a queue of the same kind as the
     * last one, which is nothing at all.
     */
    suspend fun ensurePlayerFor(firstUri: String?) {
        pendingWebPlayback = null
        val wanted = if (firstUri != null && dev.lelonio.square.data.LocalLibrary.isLocal(firstUri)) {
            PlayerKind.LOCAL
        } else {
            kindFor(container.preferences.backend.value).let { kind ->
                // An account Spotify refuses its keys goes on playing the web
                // player's way, once the engine is up to lend it a token.
                if (kind == PlayerKind.SPOTIFY && webPlaybackNeeded()) {
                    if (dev.lelonio.square.playback.websdk.WebSdkRecovery.isConfigured(this)) {
                        PlayerKind.SPOTIFY_WEB
                    } else {
                        dev.lelonio.square.playback.websdk.WebSdkRecovery.requestSetup()
                        kind
                    }
                } else kind
            }
        }
        if (wanted == playerKind) return

        // Leaving the video behind, if that is what was in front.
        //
        // Choosing a song somewhere else while a video plays is a choice to
        // listen to that song: the player swapped underneath, but the screen was
        // never told the video had ended, so it went on drawing the video's slot
        // — a black rectangle over a song that was playing perfectly well, with
        // the switch back to audio pointing at a video that no longer existed.
        if (playerKind == PlayerKind.VIDEO) {
            dev.lelonio.square.backend.spotify.SpotifyVideoMode.setEnabled(false)
            dev.lelonio.square.backend.spotify.SpotifyVideoMode.setManifest(null)
        }
        // Nothing to put back: the queue that caused this swap is about to be
        // set on the new player by the session itself.
        swapPlayer(wanted, restore = false)
    }

    private fun buildPlayer(
        backendId: dev.lelonio.square.backend.BackendId,
    ): androidx.media3.common.Player = buildPlayer(kindFor(backendId))

    private fun webPlaybackNeeded(): Boolean =
        container.preferences.backend.value == dev.lelonio.square.backend.BackendId.SPOTIFY &&
            dev.lelonio.square.backend.spotify.SpotifyWebPlayback.needed(this)

    private data class PendingWebPlayback(
        val items: List<androidx.media3.common.MediaItem>,
        val index: Int,
        val position: Long,
        val shuffle: Boolean,
        val repeat: Int,
    )
    private var pendingWebPlayback: PendingWebPlayback? = null

    /** Keep the failed selection while OAuth is completed; resume through the official SDK. */
    private suspend fun moveToWebPlayback() {
        if (playerKind != PlayerKind.SPOTIFY) return
        val engine = librespot ?: return
        if (pendingWebPlayback == null) {
            val items = (0 until engine.mediaItemCount).map(engine::getMediaItemAt)
            if (items.isEmpty()) return
            pendingWebPlayback = PendingWebPlayback(items,
                engine.currentMediaItemIndex.coerceIn(0, items.lastIndex),
                engine.currentPosition.coerceAtLeast(0), engine.shuffleModeEnabled, engine.repeatMode)
        }
        if (!dev.lelonio.square.playback.websdk.WebSdkRecovery.isConfigured(this)) {
            engine.pause()
            dev.lelonio.square.playback.websdk.WebSdkRecovery.requestSetup()
            return
        }
        val pending = pendingWebPlayback ?: return
        swapPlayer(PlayerKind.SPOTIFY_WEB, restore = false)
        player.setMediaItems(pending.items, pending.index, pending.position)
        player.shuffleModeEnabled = pending.shuffle
        player.repeatMode = pending.repeat
        player.prepare()
        player.play()
        pendingWebPlayback = null
    }

    private fun buildPlayer(
        kind: PlayerKind,
    ): androidx.media3.common.Player = when (kind) {
        PlayerKind.LOCAL -> {
            librespot = null
            playerKind = kind
            LocalPlayerFactory.create(playbackHost).also { built ->
                built.playbackParameters = androidx.media3.common.PlaybackParameters(
                    AudioEffects.speed.value,
                    AudioEffects.pitch.value,
                )
            }
        }

        // The video is an ordinary ExoPlayer: what makes it a video is the
        // media item it is given, which carries the DASH manifest and the
        // licence to decrypt it. See SpotifyVideo.
        PlayerKind.VIDEO -> {
            librespot = null
            playerKind = kind
            // The same sink as everything else that is not the engine, which is
            // where the app's own speed and pitch live: built plain, a video
            // played at one and dry while the listener had the sliders set, and
            // the effects came back only when the song did.
            androidx.media3.exoplayer.ExoPlayer.Builder(this, LocalPlayerFactory.renderers(playbackHost))
                .setLooper(playbackHost.looper)
                .setHandleAudioBecomingNoisy(true)
                .setAudioAttributes(
                    androidx.media3.common.AudioAttributes.Builder()
                        .setUsage(androidx.media3.common.C.USAGE_MEDIA)
                        .setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_MUSIC)
                        .build(),
                    /* handleAudioFocus = */ true,
                )
                .build()
                .also { built ->
                    built.playbackParameters = androidx.media3.common.PlaybackParameters(
                        AudioEffects.speed.value,
                        AudioEffects.pitch.value,
                    )
                    // A video that ends is a song that ended.
                    //
                    // This player holds one item — the video — and knows
                    // nothing about the queue, so reaching the end of it left
                    // the app sitting in silence on the last frame while a
                    // whole queue waited behind it. What happens instead is
                    // what happens when a song finishes: back to the audio
                    // player, on to the next track.
                    built.addListener(object : androidx.media3.common.Player.Listener {
                        override fun onPlaybackStateChanged(state: Int) {
                            if (state != androidx.media3.common.Player.STATE_ENDED) return
                            if (playerKind != PlayerKind.VIDEO) return
                            scope.launch {
                                runCatching {
                                    playVideoRequest(
                                        dev.lelonio.square.backend.spotify.SpotifyVideoMode
                                            .Request.Skip(forward = true),
                                    )
                                }.onFailure {
                                    android.util.Log.w(TAG, "after the video: $it")
                                }
                            }
                        }
                    })
                }
        }

        PlayerKind.SPOTIFY -> buildBackendPlayer(dev.lelonio.square.backend.BackendId.SPOTIFY)
        PlayerKind.YOUTUBE -> buildBackendPlayer(dev.lelonio.square.backend.BackendId.YOUTUBE_MUSIC)

        // Keep the engine parked for catalogue access; only the SDK owns playback.
        PlayerKind.SPOTIFY_WEB -> {
            librespot = null
            playerKind = kind
            dev.lelonio.square.playback.websdk.WebSdkPlayer(this, playbackHost.looper)
        }
    }

    private fun buildBackendPlayer(
        backendId: dev.lelonio.square.backend.BackendId,
    ): androidx.media3.common.Player = when (backendId) {
        dev.lelonio.square.backend.BackendId.SPOTIFY -> {
            val built = container.spotifyBackend.createPlayer(playbackHost) as LibrespotPlayer
            librespot = built

            // Another client pointing this device at a track of its own; see
            // LibrespotPlayer.onUnknownTrack.
            built.onUnknownTrack = { uri -> scope.launch { adoptPlayingTrack(uri) } }

            // Applied straight to the output rather than waiting for the UI: the
            // service can be running with no activity attached at all.
            audioOutput.setSpeedAndPitch(AudioEffects.speed.value, AudioEffects.pitch.value)
            built.restorePlaybackParameters(AudioEffects.speed.value, AudioEffects.pitch.value)

            NativeBridge.initContext(this)
            // Before connectEngine: the sink is built as soon as playback starts
            // and has nowhere to write without it.
            NativeBridge.setAudioOutput(audioOutput)

            // Reverb is not part of the Player interface, so it arrives here
            // rather than through the media session.
            scope.launch {
                AudioEffects.reverb.collect(audioOutput::setReverbAmount)
            }
            built
        }

        dev.lelonio.square.backend.BackendId.YOUTUBE_MUSIC -> {
            librespot = null
            container.youtubeBackend.createPlayer(playbackHost).also { built ->
                built.playbackParameters = androidx.media3.common.PlaybackParameters(
                    AudioEffects.speed.value,
                    AudioEffects.pitch.value,
                )
            }
        }
    }.also { playerKind = kindFor(backendId) }

    /**
     * Swaps the player under the running session.
     *
     * The session itself is kept: rebuilding it would drop the notification and
     * every controller bound to it, and the media session API exists precisely
     * so the player behind it can be replaced.
     */
    private fun switchBackend(backendId: dev.lelonio.square.backend.BackendId) = scope.launch {
        swapPlayer(kindFor(backendId))
    }

    /** The swap itself; see [switchBackend] and [ensurePlayerFor]. */
    private suspend fun swapPlayer(kind: PlayerKind, restore: Boolean = true) {
        // Only a player with something in it has anything to save, and saving
        // an empty one does not write nothing: it clears the store. At startup
        // the player being swapped away from is the one just built, empty, so
        // the first act of restoring a queue was deleting it.
        if (player.mediaItemCount > 0) runCatching { savePlayback() }
        saveJob?.cancel()

        // The engine goes only when another *service* takes over.
        //
        // Playing a file from the phone is not leaving Spotify: the session is
        // what the whole catalogue is read through, so shutting it down to play
        // an mp3 left the library unable to answer anything until the listener
        // went back to a Spotify track. It stays up, and the local player takes
        // the speaker for as long as it is in front.
        if (librespot != null && kind == PlayerKind.YOUTUBE) {
            // Off the main thread, and this is why the switch is a coroutine at
            // all: shutting the native engine down means stopping its threads
            // and closing its session, which took long enough to hang the input
            // queue — the app was reported as not responding, and the animation
            // meant to cover the switch never got a frame to draw in.
            runCatching { withContext(Dispatchers.IO) { NativeBridge.shutdown() } }
            engineStarted = false
        }
        // Going to a local file: the Spotify player is set aside rather than
        // released.
        //
        // Releasing it shuts the engine down — that is what its own release
        // does — and the engine is what the whole catalogue is read through.
        // Worse, it went down while the flag saying it was up stayed set, so
        // coming back built a player over an engine nobody restarted and every
        // command answered "engine not started". Parked, it keeps the session
        // alive behind the local player and is picked up again on the way back,
        // already configured.
        exoOf(player)?.let(exoReverb::release)

        // The video is the same case as a local file: the session plays
        // something else for a while, and the engine has to be there when the
        // song comes back — it is also what the whole catalogue is read
        // through while the video plays.
        val parking = librespot != null &&
            (kind == PlayerKind.LOCAL || kind == PlayerKind.VIDEO || kind == PlayerKind.SPOTIFY_WEB)
        if (parking) {
            runCatching { player.playWhenReady = false }
            parkedSpotify = librespot
            librespot = null
            playerKind = kind
            player = buildPlayer(kind)
            player.addListener(buttonsListener)
            session?.player = player
            redrawButtons()
            // The queue on disk belongs to this player when it is the one being
            // restored into — leaving it out is what made a local song paused
            // at closing time impossible to start again: the screen had it, the
            // player had nothing.
            if (restore) restoreTimeline(container.preferences.backend.value)
            followReverb()
            observeForSaving()
            return
        }

        // Coming back to a parked one: nothing to build and nothing to connect.
        val parked = parkedSpotify
        if (parked != null && kind == PlayerKind.SPOTIFY) {
            runCatching {
                player.stop()
                player.clearMediaItems()
            }
            runCatching { player.release() }
            parkedSpotify = null
            librespot = parked
            playerKind = kind
            player = parked
            player.addListener(buttonsListener)
            session?.player = player
            redrawButtons()
            if (restore) restoreQueue()
            observeForSaving()
            return
        }

        // Anything else is a real change of source, and the parked player has
        // no place in it.
        parkedSpotify?.let { stale ->
            parkedSpotify = null
            runCatching { stale.release() }
            engineStarted = false
        }

        // Emptied before it goes: the session keeps reporting whatever the old
        // player had loaded until something replaces it, and the new source's
        // queue may legitimately be empty — which would leave the previous
        // source's track sitting in the player with the new source's controls
        // around it.
        runCatching {
            player.stop()
            player.clearMediaItems()
        }
        runCatching { player.release() }
        // Video belongs to the source that was playing it.
        dev.lelonio.square.backend.youtube.YouTubeVideoMode.reset()

        player = buildPlayer(kind)
        player.addListener(buttonsListener)
        session?.player = player
        redrawButtons()
        followReverb()
        // The engine is what the Spotify player plays through, so it is started
        // whatever brought us here — without this, coming back from a local file
        // left a player wired to an engine that was never connected, and nothing
        // from Spotify would play again until the app was restarted.
        //
        // What is conditional is putting the last queue back: when the swap was
        // caused by a queue arriving, that queue is moments away and the saved
        // one would land on top of it.
        if (librespot != null) {
            connectEngine(restoreQueue = restore)
        } else {
            if (restore) restoreTimeline(container.preferences.backend.value)
            observeForSaving()
        }
    }

    /**
     * Starts whatever the active backend needs before it can play.
     *
     * For Spotify that is the engine, and the queue is put back once it has
     * connected — it is the engine that holds it. A backend playing through a
     * plain player has nothing to wait for, so its queue goes back now.
     */
    private fun startSpotifyEngineIfActive() {
        if (librespot != null) {
            connectEngine()
        } else {
            restoreTimeline(container.preferences.backend.value)
            observeForSaving()
        }
        restoreLocalQueueIfLast()
    }

    /**
     * Puts a queue of the phone's own files back after a restart.
     *
     * It cannot be done by starting with the local player, which is what was
     * tried first: the engine is started by the Spotify player, everything the
     * catalogue does needs the engine, and coming up without it left the
     * library on its spinner for ever. So the session starts as it always did
     * and the local player is swapped in afterwards, with the engine left
     * running behind it.
     */
    private fun restoreLocalQueueIfLast() {
        val saved = runCatching { playbackStore.load() }.getOrNull() ?: return
        val first = saved.tracks.firstOrNull()?.uri ?: return
        if (!dev.lelonio.square.data.LocalLibrary.isLocal(first)) return
        scope.launch {
            // Not if something has started in the meantime.
            //
            // This is queued at startup and runs whenever the engine has
            // finished coming up, which can be after the listener has already
            // opened a playlist and tapped a song. Swapping then put the local
            // player — holding the file that was paused when the app was last
            // closed — in front of a session that was playing something else:
            // the new song came out of the speaker while the screen showed the
            // old one, paused.
            if (player.mediaItemCount > 0) return@launch
            swapPlayer(PlayerKind.LOCAL, restore = true)
        }
    }

    /** Upcoming tracks already asked about, so a run of updates asks once. */
    private val askedNext = mutableSetOf<String>()
    private val ASKED_NEXT_LIMIT = 500

    /**
     * Names the tracks coming up on the other device that it did not name.
     *
     * The queue shown for another device is what it publishes as next, and a
     * client that leaves the title off the current track leaves it off those
     * too. One catalogue read for all of them; a local file is described by its
     * own URI, which spells out its tags.
     */
    private suspend fun describeRemoteNext(playback: dev.lelonio.square.data.RemotePlayback) {
        val unnamed = playback.next.filter { it.title.isEmpty() && it.uri !in askedNext }
        if (unnamed.isEmpty()) return
        // Bounded: a day of following another device's queue is a lot of
        // tracks, and an answer already given is kept by RemoteConnect.
        if (askedNext.size > ASKED_NEXT_LIMIT) askedNext.clear()
        val local = unnamed.filter { dev.lelonio.square.data.LocalLibrary.isSpotifyLocal(it.uri) }.map { track ->
            val parts = track.uri.removePrefix(dev.lelonio.square.data.LocalLibrary.SPOTIFY_PREFIX).split(':')
                .map { runCatching { java.net.URLDecoder.decode(it, "UTF-8") }.getOrDefault(it) }
            track.copy(artist = parts.getOrNull(0).orEmpty(), title = parts.getOrNull(2).orEmpty())
        }
        val catalogue = unnamed.map { it.uri }.filter { it.startsWith("spotify:track:") }
        val read = if (catalogue.isEmpty()) emptyList() else {
            runCatching { dev.lelonio.square.data.Catalog.tracks(catalogue) }
                .onFailure { android.util.Log.w(TAG, "cannot read what comes next there: $it") }
                .getOrDefault(emptyList())
                .map { track ->
                    dev.lelonio.square.data.RemoteTrack(track.uri, track.name, track.artist, track.artworkUrl.orEmpty())
                }
        }
        // Only what was answered counts as asked: a read that failed on a
        // dropped connection is tried again with the next update, rather than
        // leaving those tracks without a name for the rest of the session.
        askedNext += local.map { it.uri } + read.map { it.uri }
        if (local.isNotEmpty() || read.isNotEmpty()) {
            dev.lelonio.square.data.RemoteConnect.describeNext(local + read)
        }
    }

    /**
     * Fills in what the other device did not say about its track.
     *
     * Whether a client publishes a title and an artist beside the uri is up to
     * that client: the web player does, the desktop app does not always, and
     * what reached the notification then was a song with no name. The uri is
     * always there, and this app can read a track from a uri, so it does.
     */
    private suspend fun describeRemote(
        playback: dev.lelonio.square.data.RemotePlayback,
    ): dev.lelonio.square.data.RemotePlayback {
        describeRemoteNext(playback)
        if (playback.title.isNotEmpty() && playback.artist.isNotEmpty()) return playback
        val track = runCatching { container.activeBackend.tracksOf(playback.uri).firstOrNull() }
            .onFailure { android.util.Log.w(TAG, "cannot read ${playback.uri}: $it") }
            .getOrNull() ?: return playback

        val filled = playback.copy(
            title = playback.title.ifEmpty { track.name },
            artist = playback.artist.ifEmpty { track.artist },
            album = playback.album.ifEmpty { track.album },
            coverUri = playback.coverUri.ifEmpty { track.artworkUrl.orEmpty() },
        )
        // Kept there rather than here: every part of the app reads that state,
        // and the next cluster update rebuilds it from what the other device
        // published, which is what left this out in the first place.
        dev.lelonio.square.data.RemoteConnect.describe(filled)
        return filled
    }

    /** The queue last taken on, so the same transfer is not resolved twice. */
    private var adoptedContext: String? = null

    /**
     * Fills in the queue behind a track the engine was handed.
     *
     * Only when this side does not already know the track: playing from Square
     * puts it in the queue first, and re-resolving the context then would throw
     * away the order the listener is looking at.
     */
    private suspend fun adoptRemoteQueue(here: dev.lelonio.square.data.RemotePlayback?) {
        val engine = librespot ?: return
        if (here == null || here.uri.isEmpty()) return
        if (queue?.items.orEmpty().any { it.uri == here.uri }) return

        val key = "${here.contextUri}|${here.uri}"
        if (adoptedContext == key) return
        adoptedContext = key

        val tracks = runCatching {
            container.activeBackend.tracksOf(here.realContext ?: here.uri)
        }
            .onFailure { android.util.Log.w(TAG, "handed a queue we cannot read: $it") }
            .getOrDefault(emptyList())

        val index = tracks.indexOfFirst { it.uri == here.uri }
        if (tracks.isEmpty()) return
        // A long context takes seconds to read, and an answer about a track the
        // engine has already left behind would drag the screen back to it; see
        // adoptPlayingTrack.
        val playing = engineUri()
        if (playing.isNotEmpty() && playing != here.uri) {
            android.util.Log.i(TAG, "${here.uri} is over by now, leaving the queue alone")
            return
        }

        engine.adopt(
            tracks = tracks.map(::toQueueTrack),
            index = index.coerceAtLeast(0),
            positionMs = here.positionMs,
            contextUri = here.realContext,
            contextLabel = "",
            playing = here.playing,
        )
    }

    /**
     * Puts the queue behind a track another client started here.
     *
     * A pause on this phone and a tap in the web player on some playlist track:
     * the engine obeys and plays it, and this side had no idea. Not a transfer,
     * so nothing arrives that way, and not a cluster update either, since the
     * account does not describe a device to that device. The Connect state the
     * engine publishes is the one place the answer exists, so it is asked
     * directly, and what comes back is resolved the same way a handover is.
     */
    private suspend fun adoptPlayingTrack(uri: String) {
        val engine = librespot ?: return

        val here = withContext(Dispatchers.IO) {
            runCatching { org.json.JSONObject(NativeBridge.playingHere()) }
                .onFailure { android.util.Log.w(TAG, "cannot read what we play: $it") }
                .getOrNull()
        }
        val contextUri = here?.optString("contextUri").orEmpty()
        val source = contextUri.takeIf {
            it.isNotEmpty() && it.startsWith("spotify:") && !it.startsWith("spotify:web-api")
        }

        val key = "$contextUri|$uri"
        if (adoptedContext == key) return
        adoptedContext = key

        // The context first, because it is the whole list in its own order: a
        // playlist read this way comes back complete, while what the account
        // hands a device is a window of the next few dozen tracks.
        var tracks = if (source == null) {
            emptyList()
        } else {
            withContext(Dispatchers.IO) {
                runCatching { container.activeBackend.tracksOf(source) }
                    .onFailure { android.util.Log.w(TAG, "cannot read $source: $it") }
                    .getOrDefault(emptyList())
            }
        }

        // Nothing came back, which is the normal answer for the playlists
        // Spotify makes rather than stores: a daily mix, a radio, "Pop Mix"
        // exist for the account and resolve to nothing for anyone else. The
        // account sent the list along with the order to play it, so that is
        // what is used.
        if (tracks.none { it.uri == uri }) {
            val queued = buildList {
                val array = here?.optJSONArray("tracks")
                for (i in 0 until (array?.length() ?: 0)) add(array!!.getString(i))
            }
            tracks = withContext(Dispatchers.IO) {
                runCatching { dev.lelonio.square.data.Catalog.tracks(queued) }
                    .onFailure { android.util.Log.w(TAG, "cannot read the engine's queue: $it") }
                    .getOrDefault(emptyList())
            }
            android.util.Log.i(TAG, "adopting ${tracks.size} tracks from the engine itself")
        } else {
            android.util.Log.i(TAG, "adopting ${tracks.size} tracks from $source")
        }

        val index = tracks.indexOfFirst { it.uri == uri }
        if (index < 0) return
        // Resolving a long context takes seconds, and in those seconds the
        // listener can have moved on: an answer about a track that is no longer
        // playing would put the screen somewhere the engine has already left.
        if (engineUri() != uri) {
            android.util.Log.i(TAG, "$uri is over by now, leaving the queue alone")
            return
        }

        engine.adopt(
            tracks = tracks.map(::toQueueTrack),
            index = index,
            positionMs = 0L,
            contextUri = source,
            contextLabel = "",
            playing = true,
        )
    }

    /** What the engine says it is playing this instant. */
    private suspend fun engineUri(): String = withContext(Dispatchers.IO) {
        runCatching { org.json.JSONObject(NativeBridge.playingHere()).optString("trackUri") }
            .getOrDefault("")
    }

    /**
     * Rebuilds the engine so a new bitrate takes effect.
     *
     * librespot reads the bitrate when a track loads but the player owns its
     * configuration until it is dropped, so there is nothing to set: the
     * session is torn down and started again. The queue and position are saved
     * first and put back after, which is the same path a cold start takes.
     */
    /**
     * Rebuilds the player so a new bitrate or crossfade takes effect.
     *
     * The engine is not shut down for this any more. Tearing it down from here
     * meant dropping the tokio runtime from a JNI thread while librespot's own
     * threads were still inside it, which aborted the process on a destroyed
     * mutex: that is the crash that came back the moment the audio quality was
     * changed. The engine can now replace its session and player on its own and
     * leave the runtime and the output alone; all this side has to do is hand
     * the queue back afterwards, since the new Connect device has never seen it.
     */
    private fun reconfigureEngine(reason: String) {
        if (rebuilding) return
        val engine = librespot ?: return
        if (!engineStarted) return
        rebuilding = true
        val wasPlaying = player.playWhenReady
        val position = player.currentPosition.coerceAtLeast(0)
        runCatching { savePlayback() }
        android.util.Log.i(TAG, "rebuilding the player ($reason)")

        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    android.util.Log.i(
                        TAG,
                        "quality: asking for ${'$'}{quality.bitrateKbps()} kbps" +
                            " (link estimate ${'$'}{quality.linkKbps()} kbps)",
                    )
                    NativeBridge.setQuality(quality.bitrateKbps(), crossfade.durationMs())
                }
                    .onFailure { android.util.Log.e(TAG, "could not rebuild the player: $it") }
                    .isSuccess
            }
            rebuilding = false
            if (!ok) return@launch
            // The queue on screen is untouched and is still the right one; the
            // engine's copy went with the session.
            engine.reloadQueue(playing = wasPlaying, positionMs = position)
        }
    }

    /**
     * Whether a rebuild is already under way.
     *
     * The loss is noticed after every command, so a listener pressing skip twice
     * while offline would otherwise ask for a second teardown in the middle of
     * the first one.
     */
    private var rebuilding = false


    /**
     * Re-runs [connectEngine] on demand.
     *
     * The service is created when the UI binds its controller, which happens
     * before the user has logged in, so the engine cannot be started once in
     * [onCreate] and left alone. The login flow sends this action when it has a
     * session.
     */
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CONNECT) connectEngine()
        return super.onStartCommand(intent, flags, startId)
    }

    /**
     * Authenticates the native session. Runs off the main thread because the
     * access-point handshake is blocking.
     */
    private fun connectEngine(restoreQueue: Boolean = true) = scope.launch {
        // Guards against the repeated ACTION_CONNECT the UI may send: the native
        // side rejects a second start, and that error would look like a login
        // failure and clear a perfectly good session.
        if (engineStarted || !container.spotifySignedIn) return@launch
        // Nothing to authenticate against while another backend is playing, and
        // starting the engine would take the audio device out from under it.
        val engine = librespot ?: return@launch
        engineStarted = true

        // Before the engine plays anything. The player asks this store on every
        // load, and setting it later would leave a window in which a downloaded
        // track streamed instead of playing from the phone.
        withContext(Dispatchers.IO) {
            container.downloads.load()
            runCatching {
                NativeBridge.setDownloadRoot(container.downloads.root.absolutePath)
            }.onFailure {
                android.util.Log.w(TAG, "downloads have no home: $it")
            }
        }

        runCatching {
            // Empty is a real answer here. The engine keeps the credential the
            // access point issued and prefers it, so a token is only needed by a
            // device logging in for the first time: refusing to start without
            // one would throw away a session that works because the OAuth half
            // of it, which playback does not use, has lapsed.
            val kept = dev.lelonio.square.auth.EngineCredentials.exist(this@PlaybackService)
            val accessToken = runCatching { tokens.validAccessToken() }
                .getOrElse { error ->
                    if (!kept) throw error
                    android.util.Log.w(TAG, "no token, logging in with the kept credential", error)
                    ""
                }
            withContext(Dispatchers.IO) {
                NativeBridge.start(
                    // Must match the id the OAuth token was minted for.
                    // `Login5Manager::auth_token` always asks as a stored
                    // credential, and that path signs the request with the
                    // session's client id — so the two have to agree or the
                    // access point rejects every catalogue call.
                    clientId = SpotifyOAuth.CLIENT_ID,
                    deviceName = android.os.Build.MODEL ?: "Android",
                    // Kept across launches, so the account sees this phone as
                    // one device rather than a new one every time.
                    deviceId = container.preferences.deviceId(),
                    accessToken = accessToken,
                    // filesDir, not cacheDir: credentials must survive the
                    // system reclaiming cache space, or the next launch loses
                    // catalogue access until the user logs in again.
                    credentialsDir = filesDir.resolve("librespot").absolutePath,
                    cacheDir = cacheDir.absolutePath,
                    // The app's own language, not the account's. Spotify
                    // localises what it answers with, artwork included: the
                    // generated playlists carry the language in the cover's
                    // URL, so the tiles came back in English.
                    language = appLanguage(),
                    bitrateKbps = quality.bitrateKbps().also {
                        android.util.Log.i(
                            TAG,
                            "quality: starting at ${'$'}it kbps" +
                                " (link estimate ${'$'}{quality.linkKbps()} kbps)",
                        )
                    },
                    // Off is zero, which is upstream librespot's own behaviour.
                    crossfadeMs = crossfade.durationMs(),
                    listener = engine,
                )
            }
            // The engine starts on librespot's own defaults, which cut a track
            // off the moment another is asked for; see PlayerConfig.
            withContext(Dispatchers.IO) {
                runCatching {
                    NativeBridge.setSkipFade(container.preferences.skipFadeMs())
                }
            }
        }.onFailure { error ->
            engineStarted = false
            android.util.Log.e(TAG, "engine start failed: $error", error)
            // Not up at all, which on no data is ordinary: the keeper starts it
            // again when there is a chance it works. A refused account below
            // signs out, and the keeper then finds nothing wanted.
            dev.lelonio.square.playback.OfflineMode.setNoSession(true)
            SessionKeeper.sessionMissing()
            // Only a refused account ends the session here. Everything else the
            // handshake can fail with — no network, an access point that is
            // busy, a dealer that dropped — is temporary, and signing the user
            // out over it costs them their session for a failure that would
            // have fixed itself on the next attempt. A refresh token Spotify
            // really has revoked is cleared by TokenStore before it gets here.
            if (error.message?.contains(PREMIUM_REQUIRED) == true) {
                // Back to the login screen, with a reason. Staying signed in
                // would leave an app that looks connected and plays nothing.
                tokens.clear()
                dev.lelonio.square.auth.EngineCredentials.clear(this@PlaybackService)
                android.widget.Toast.makeText(
                    this@PlaybackService,
                    getString(dev.lelonio.square.R.string.premium_required),
                    android.widget.Toast.LENGTH_LONG,
                ).show()
            }
        }.onSuccess {
            // Started is not the same as connected any more. With music on the
            // phone the engine comes up even when the handshake failed, with a
            // player and no session, and the app has to know which of the two
            // it got: everything that streams is unavailable in the second, and
            // the downloads play exactly as they always did.
            val offline = runCatching { NativeBridge.isOffline }.getOrDefault(false)
            dev.lelonio.square.playback.OfflineMode.setNoSession(offline)
            android.util.Log.i(TAG, if (offline) "engine started offline" else "engine connected")
            // Before the queue is handed over: a local song that was playing
            // when the app closed is only playable once the engine knows its
            // file; see LocalFileBindings. Entries of the saved queue never
            // matched yet (saved by an older build, or never shown on a page
            // since) are matched here, against the phone's own music, rather
            // than left silent until their playlist is opened.
            runCatching { bindSavedLocalEntries() }
                .onFailure { android.util.Log.w(TAG, "local files not matched: $it") }
            dev.lelonio.square.data.LocalFileBindings.push()
            // Up with no session: try again for as long as there is a network.
            if (offline) SessionKeeper.sessionMissing()
            if (restoreQueue) restoreQueue()
            observeForSaving()
        }
    }

    /** See the note where it is called, as the engine starts. */
    private suspend fun bindSavedLocalEntries() {
        val saved = playbackStore.load() ?: return
        val unmatched = saved.tracks.filter {
            dev.lelonio.square.data.LocalLibrary.isSpotifyLocal(it.uri) &&
                !dev.lelonio.square.data.LocalFileBindings.has(it.uri)
        }
        if (unmatched.isEmpty()) return
        val files = dev.lelonio.square.data.LocalLibrary.tracks(this)
        val found = unmatched.mapNotNull { entry ->
            dev.lelonio.square.data.LocalLibrary.match(entry, files)?.localFile?.let { entry.uri to it }
        }.toMap()
        android.util.Log.i(TAG, "matched ${found.size} of ${unmatched.size} local entries of the saved queue")
        dev.lelonio.square.data.LocalFileBindings.bind(found)
    }

    /**
     * Puts the last queue back, paused at the saved position.
     *
     * Skipped when something is already loaded: the user opened the app, played
     * something and only then did the engine finish connecting, and overwriting
     * that would be worse than not restoring at all.
     */
    private fun restoreQueue(handOverNow: Boolean = true) {
        val engine = librespot ?: return
        if (player.mediaItemCount > 0) {
            // Already on screen from the early restore; all that is left is to
            // give it to the engine that has just come up.
            if (handOverNow) engine.handOverToEngine()
            return
        }
        val saved = playbackStore.load() ?: return
        // Spotify's own queue only. The store holds whichever source was last
        // playing, and handing librespot a queue of `ytmusic:` URIs would fill
        // the player with tracks it cannot load.
        if (saved.tracks.none { it.uri.startsWith("spotify:") }) return

        // One call rather than a sequence of commands: see LibrespotPlayer.restore
        // for why the order, position and modes have to be applied together.
        engine.restore(
            tracks = saved.tracks.map(::toQueueTrack),
            shuffleOrder = saved.shuffleOrder,
            index = saved.index,
            positionMs = saved.positionMs,
            repeatMode = saved.repeatMode,
            contextUri = saved.contextUri,
            contextIsOrdered = saved.contextOrdered,
            contextLabel = saved.contextLabel,
            handOverNow = handOverNow,
            smartShuffle = saved.smartShuffle,
        )
        android.util.Log.i(TAG, "restored ${saved.tracks.size} tracks at ${saved.index}")
    }

    /**
     * Writes the queue back on every meaningful change, and on a slow tick while
     * playing.
     *
     * The tick is what makes the *position* survive being force-stopped, which
     * fires no lifecycle callback at all; events alone would only ever save the
     * position at the moment playback started.
     */
    private fun observeForSaving() {
        player.addListener(object : androidx.media3.common.Player.Listener {
            override fun onEvents(
                p: androidx.media3.common.Player,
                events: androidx.media3.common.Player.Events,
            ) {
                if (events.containsAny(
                        androidx.media3.common.Player.EVENT_TIMELINE_CHANGED,
                        androidx.media3.common.Player.EVENT_MEDIA_ITEM_TRANSITION,
                        androidx.media3.common.Player.EVENT_IS_PLAYING_CHANGED,
                        androidx.media3.common.Player.EVENT_SHUFFLE_MODE_ENABLED_CHANGED,
                        androidx.media3.common.Player.EVENT_REPEAT_MODE_CHANGED,
                    )
                ) {
                    savePlayback()
                    recordEpisode()
                }
            }

            // An episode that ran into the next one was heard to the end.
            override fun onMediaItemTransition(
                mediaItem: androidx.media3.common.MediaItem?,
                reason: Int,
            ) {
                val left = episodePlaying
                episodePlaying = mediaItem?.mediaId
                if (left != null && left != mediaItem?.mediaId &&
                    reason == androidx.media3.common.Player.MEDIA_ITEM_TRANSITION_REASON_AUTO
                ) {
                    (application as dev.lelonio.square.SquareApplication).episodeProgress.finished(left)
                }
            }
        })

        saveJob?.cancel()
        saveJob = scope.launch {
            while (true) {
                delay(SAVE_INTERVAL_MS)
                if (player.isPlaying) {
                    savePlayback()
                    recordEpisode()
                }
            }
        }
    }

    /**
     * The queue to resume from a media button; see MediaBrowseTree.onPlaybackResumption.
     *
     * Whatever the player already holds, which is the saved session put back
     * when the service started; failing that, the saved session itself.
     */
    private fun resumption(): MediaSession.MediaItemsWithStartPosition? {
        if (player.mediaItemCount == 0) {
            runCatching { restoreTimeline(container.preferences.backend.value) }
        }
        val count = player.mediaItemCount
        if (count == 0) return null
        return MediaSession.MediaItemsWithStartPosition(
            (0 until count).map(player::getMediaItemAt),
            player.currentMediaItemIndex.coerceIn(0, count - 1),
            player.currentPosition.coerceAtLeast(0),
        )
    }

    /**
     * Keeps the home-screen widget on the song and the state playing.
     *
     * Read once a second rather than from listener events: the player is
     * swapped whole when the source changes, and the widget only redraws when
     * what it shows has actually changed; see SquareWidget.publish.
     */
    private fun startWidgetUpdates() {
        scope.launch {
            while (true) {
                val item = player.currentMediaItem
                val metadata = item?.mediaMetadata
                val title = metadata?.title?.toString()
                if (!title.isNullOrBlank()) {
                    dev.lelonio.square.widget.SquareWidget.publish(
                        this@PlaybackService,
                        dev.lelonio.square.widget.SquareWidget.NowPlaying(
                            title = title,
                            artist = metadata.artist?.toString().orEmpty(),
                            artworkUri = metadata.artworkUri?.toString(),
                            playing = player.isPlaying,
                        ),
                    )
                }
                delay(1_000)
            }
        }
    }

    /** Measures only playback on this device, independently of the activity. */
    private fun startListeningRecorder() {
        val sampler = dev.lelonio.square.data.ListeningSampler()
        scope.launch {
            var owner: String? = null
            var sampledPlayer: androidx.media3.common.Player? = null
            var lastSaved = 0L
            var previouslyPlaying = false
            val listener = object : androidx.media3.common.Player.Listener {
                override fun onMediaItemTransition(item: androidx.media3.common.MediaItem?, reason: Int) {
                    sampler.sample(null, false, System.currentTimeMillis(), android.os.SystemClock.elapsedRealtime())?.let { event ->
                        owner?.let { account -> scope.launch { container.listeningStore.record(event, account) } }
                    }
                }
            }
            try {
                while (true) {
                    // Filed under the source it was played from: Spotify's
                    // account, or YouTube Music's history on this phone.
                    val source = when (container.preferences.backend.value) {
                        dev.lelonio.square.backend.BackendId.SPOTIFY -> dev.lelonio.square.data.ListeningStore.Source.SPOTIFY
                        dev.lelonio.square.backend.BackendId.YOUTUBE_MUSIC -> dev.lelonio.square.data.ListeningStore.Source.YOUTUBE_MUSIC
                    }
                    val account = container.listeningStore.ownerOf(source)
                    if (account != owner) { sampler.reset(); owner = account }
                    if (sampledPlayer !== player) {
                        sampledPlayer?.removeListener(listener)
                        sampledPlayer = player
                        player.addListener(listener)
                    }
                    val remote = (player as? LibrespotPlayer)?.isRemotePlayback == true
                    val item = player.currentMediaItem
                    val metadata = item?.mediaMetadata
                    val track = if (!remote && account != null && item != null &&
                        !metadata?.title.isNullOrBlank()) CatalogTrack(
                        uri = item.mediaId,
                        name = metadata?.title.toString(),
                        artist = metadata?.artist?.toString().orEmpty(),
                        artists = creditedArtists(metadata?.extras),
                        album = metadata?.albumTitle?.toString().orEmpty(),
                        albumUri = metadata?.extras?.getString(dev.lelonio.square.ui.EXTRA_ALBUM_URI),
                        durationMs = metadata?.durationMs ?: player.duration.coerceAtLeast(0),
                        artworkUrl = metadata?.artworkUri?.toString(),
                    ) else null
                    val tick = android.os.SystemClock.elapsedRealtime()
                    val event = sampler.sample(track, player.isPlaying && !remote, System.currentTimeMillis(), tick)
                    if (event != null && (tick - lastSaved >= 10_000 || previouslyPlaying != player.isPlaying || event.track.uri != track?.uri)) {
                        account?.let { container.listeningStore.record(event, it) }
                        lastSaved = tick
                    }
                    previouslyPlaying = player.isPlaying
                    delay(1_000)
                }
            } finally {
                sampledPlayer?.removeListener(listener)
                val event = sampler.sample(null, false, System.currentTimeMillis(), android.os.SystemClock.elapsedRealtime())
                if (event != null && owner != null) kotlinx.coroutines.withContext(kotlinx.coroutines.NonCancellable) {
                    container.listeningStore.record(event, owner!!)
                }
            }
        }
    }

    /**
     * Snapshots the queue.
     *
     * Read from [PlayQueue] rather than through the Media3 timeline because only
     * the queue knows the pre-shuffle order and the permutation on top of it;
     * the timeline exposes just the current sequence.
     */
    /** What was playing at the last transition, for marking it heard; see observeForSaving. */
    private var episodePlaying: String? = null

    /** Where the episode playing has got to; see EpisodeProgress. */
    private fun recordEpisode() {
        val uri = player.currentMediaItem?.mediaId ?: return
        if (!uri.startsWith("spotify:episode:")) return
        (application as dev.lelonio.square.SquareApplication).episodeProgress
            .record(uri, player.currentPosition, player.duration.coerceAtLeast(0))
    }

    private fun savePlayback() {
        // A backend with no PlayQueue behind it — the YouTube one — is saved off
        // the Media3 timeline instead. That loses the pre-shuffle order, which
        // only librespot's queue knows, so a shuffled queue comes back in the
        // order it was actually playing rather than the order it was built in.
        val queue = queue ?: return saveTimeline()
        if (queue.items.isEmpty()) {
            playbackStore.clear()
            return
        }

        playbackStore.save(
            SavedPlayback(
                tracks = queue.originalTracks.map(::toCatalogTrack),
                shuffleOrder = queue.shuffleOrder,
                smartShuffle = queue.smartShuffle,
                index = queue.currentIndex,
                positionMs = player.currentPosition.coerceAtLeast(0),
                repeatMode = player.repeatMode,
                contextUri = queue.contextUri,
                contextOrdered = queue.contextIsOrdered,
                contextLabel = queue.contextLabel,
            ),
        )
    }

    /**
     * The same snapshot, taken from the player's own timeline.
     *
     * Everything written here is already in the media items — the app puts the
     * track's URI, its metadata and the context it came from into each one — so
     * this is a read of what is loaded rather than a second bookkeeping of it.
     */
    private fun saveTimeline() {
        val count = player.mediaItemCount
        if (count == 0) {
            playbackStore.clear()
            return
        }
        val tracks = (0 until count).map { index ->
            val item = player.getMediaItemAt(index)
            val metadata = item.mediaMetadata
            CatalogTrack(
                uri = item.mediaId,
                name = metadata.title?.toString().orEmpty(),
                artist = metadata.artist?.toString().orEmpty(),
                // Kept per track rather than taken from the current one: the
                // artist page a row opens is its own.
                artistUri = metadata.extras
                    ?.getString(dev.lelonio.square.ui.EXTRA_ARTIST_URI),
                artists = creditedArtists(metadata.extras),
                durationMs = metadata.durationMs ?: 0L,
                artworkUrl = metadata.artworkUri?.toString(),
            )
        }
        val currentTrack = tracks.getOrNull(player.currentMediaItemIndex)
        if (currentTrack != null && currentTrack.name.isBlank()) return
        val extras = player.currentMediaItem?.mediaMetadata?.extras
        playbackStore.save(
            SavedPlayback(
                tracks = tracks,
                shuffleOrder = null,
                index = player.currentMediaItemIndex,
                positionMs = player.currentPosition.coerceAtLeast(0),
                repeatMode = player.repeatMode,
                contextUri = extras?.getString(dev.lelonio.square.ui.EXTRA_CONTEXT_URI),
                contextOrdered = extras?.getBoolean(dev.lelonio.square.ui.EXTRA_CONTEXT_ORDERED) == true,
                contextLabel = extras?.getString(dev.lelonio.square.ui.EXTRA_CONTEXT_LABEL).orEmpty(),
            ),
        )
    }

    /**
     * Puts the last queue back into a plain [androidx.media3.common.Player].
     *
     * Paused, like the Spotify one: see [dev.lelonio.square.data.PlaybackStore].
     * A queue saved by the other backend is left alone — its URIs mean nothing
     * to this player, and loading them would fill the screen with tracks that
     * fail one after another.
     */
    private fun restoreTimeline(backendId: dev.lelonio.square.backend.BackendId) {
        if (player.mediaItemCount > 0) return
        val saved = playbackStore.load() ?: return
        // The phone's own files belong to no backend, so they are matched
        // against the player that is actually behind the session rather than
        // against a catalogue.
        if (playerKind == PlayerKind.LOCAL) {
            if (saved.tracks.none { dev.lelonio.square.data.LocalLibrary.isLocal(it.uri) }) return
        } else {
            val backend = when (backendId) {
                dev.lelonio.square.backend.BackendId.SPOTIFY -> container.spotifyBackend
                dev.lelonio.square.backend.BackendId.YOUTUBE_MUSIC -> container.youtubeBackend
            }
            if (saved.tracks.none { backend.owns(it.uri) }) return
        }

        player.setMediaItems(
            saved.tracks.map { track ->
                androidx.media3.common.MediaItem.Builder()
                    .setMediaId(track.uri)
                    .setUri(track.uri)
                    .setMediaMetadata(
                        androidx.media3.common.MediaMetadata.Builder()
                            .setTitle(track.name)
                            .setArtist(track.artist)
                            .setAlbumTitle(track.album.takeIf { it.isNotEmpty() })
                            .setDurationMs(track.durationMs.takeIf { it > 0 })
                            .setArtworkUri(track.artworkUrl?.let(android.net.Uri::parse))
                            .setExtras(
                                android.os.Bundle().apply {
                                    track.artistUri?.let {
                                        putString(dev.lelonio.square.ui.EXTRA_ARTIST_URI, it)
                                    }
                                    track.albumUri?.let {
                                        putString(dev.lelonio.square.ui.EXTRA_ALBUM_URI, it)
                                    }
                                    if (track.explicit) {
                                        putBoolean(dev.lelonio.square.ui.EXTRA_EXPLICIT, true)
                                    }
                                    val credited = track.artists.filter { it.uri != null }
                                    if (credited.isNotEmpty()) {
                                        putStringArrayList(
                                            dev.lelonio.square.ui.EXTRA_ARTIST_NAMES,
                                            ArrayList(credited.map { it.name }),
                                        )
                                        putStringArrayList(
                                            dev.lelonio.square.ui.EXTRA_ARTIST_URIS,
                                            ArrayList(credited.map { it.uri!! }),
                                        )
                                    }
                                    saved.contextUri?.let {
                                        putString(dev.lelonio.square.ui.EXTRA_CONTEXT_URI, it)
                                    }
                                    putBoolean(
                                        dev.lelonio.square.ui.EXTRA_CONTEXT_ORDERED,
                                        saved.contextOrdered,
                                    )
                                    putString(
                                        dev.lelonio.square.ui.EXTRA_CONTEXT_LABEL,
                                        saved.contextLabel,
                                    )
                                },
                            )
                            .build(),
                    )
                    .build()
            },
            saved.index.coerceIn(0, saved.tracks.lastIndex),
            saved.positionMs,
        )
        player.repeatMode = saved.repeatMode
        player.prepare()
        android.util.Log.i(TAG, "restored ${saved.tracks.size} tracks at ${saved.index}")
    }

    private fun toCatalogTrack(track: PlayQueue.Track) = CatalogTrack(
        uri = track.uri,
        name = track.title,
        artist = track.artist,
        artistUri = track.artistUri,
        artists = track.artists,
        durationMs = track.durationMs,
        artworkUrl = track.artworkUri?.toString(),
        smartRecommended = track.recommended,
    )

    private fun toQueueTrack(track: CatalogTrack) = PlayQueue.Track(
        uri = track.uri,
        title = track.name,
        artist = track.artist,
        artistUri = track.artistUri,
        artists = track.artists,
        album = track.album,
        albumUri = track.albumUri,
        durationMs = track.durationMs,
        artworkUri = track.artworkUrl?.let(android.net.Uri::parse),
        explicit = track.explicit,
        recommended = track.smartRecommended,
    )

    /** The two parallel lists put back together; see EXTRA_ARTIST_NAMES. */
    private fun creditedArtists(
        extras: android.os.Bundle?,
    ): List<dev.lelonio.square.data.CatalogArtist> {
        val names = extras?.getStringArrayList(dev.lelonio.square.ui.EXTRA_ARTIST_NAMES)
        val uris = extras?.getStringArrayList(dev.lelonio.square.ui.EXTRA_ARTIST_URIS)
        if (names == null || uris == null) return emptyList()
        return names.zip(uris) { name, uri -> dev.lelonio.square.data.CatalogArtist(name, uri) }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaLibrarySession? =
        session

    /**
     * Stays in the foreground while paused, which Media3 does not do on its own.
     *
     * Pausing makes it call this with `false`, the service drops out of the
     * foreground, and the notification is left attached to a process the system
     * is now free to reclaim. It usually does, within minutes, and what the
     * listener sees is the shade quietly emptying: the track they paused is
     * gone, and with it the one control that would have resumed it.
     *
     * Media playback is exactly what this kind of service is for, and the way
     * out of it is still the obvious one: swiping the app away stops the service
     * in [onTaskRemoved], which is where a paused session really should end.
     */
    override fun onUpdateNotification(session: MediaSession, startInForegroundRequired: Boolean) {
        // Kept rather than started. A foreground service may only be started
        // from the foreground, and this is also called for a service brought up
        // in the background — a media button, the car binding — where forcing it
        // would be the system refusing and taking the process with it. Staying
        // in a state already entered legitimately is always allowed.
        if (startInForegroundRequired) heldForeground = true
        super.onUpdateNotification(
            session,
            startInForegroundRequired || (heldForeground && player.mediaItemCount > 0),
        )
    }

    /** Whether playback has put this service in the foreground at least once. */
    private var heldForeground = false

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Saved first: this is the last chance to record where the track was,
        // and stopping is what makes the position worth having.
        runCatching { savePlayback() }
        // Closing a controller must leave the other device playing. Media3's
        // helper pauses every player, including our mirrored Connect player.
        if (dev.lelonio.square.data.RemoteConnect.elsewhereActive.value) {
            stopSelf()
            return
        }
        // Swiping the app away stops it. The service used to survive a swipe
        // while something was playing, on the grounds that killing audio
        // mid-track is rude, but a player that goes on after its app has been
        // dismissed is a player the gesture did not reach: the one obvious way
        // to stop it did nothing, and what was left was a notification the user
        // had already tried to get rid of.
        //
        // Unless the listener has asked for the music to survive the gesture:
        // a swipe is easy to make by accident, and losing the song for it is
        // what #27 asked about. The notification is still there to stop it.
        if (container.preferences.keepPlayingOnClose.value && player.isPlaying) {
            android.util.Log.i(TAG, "task removed while playing; kept alive by the setting")
            return
        }

        // Media3's own helper rather than a bare stopSelf: it pauses every
        // player attached to the service first, so the engine is told to stop
        // instead of being cut off when onDestroy releases it.
        pauseAllPlayersAndStopSelf()
    }

    override fun onDestroy() {
        SessionKeeper.engine = null
        // Before cancelling the scope: the last position is the one worth having.
        runCatching { savePlayback() }
        // Nothing plays once the service is gone, whatever the widget last heard.
        runCatching {
            player.currentMediaItem?.mediaMetadata?.let { metadata ->
                dev.lelonio.square.widget.SquareWidget.publish(
                    this,
                    dev.lelonio.square.widget.SquareWidget.NowPlaying(
                        title = metadata.title?.toString().orEmpty(),
                        artist = metadata.artist?.toString().orEmpty(),
                        artworkUri = metadata.artworkUri?.toString(),
                        playing = false,
                    ),
                )
            }
        }
        scope.cancel()
        session?.run {
            player.release()
            release()
        }
        session = null
        // Only if there is an engine to stop. Reaching for the Spotify backend
        // here would otherwise build its audio sink just to release it.
        if (librespot != null) {
            NativeBridge.shutdown()
            audioOutput.release()
        }
        super.onDestroy()
    }

    companion object {
        private const val TAG = "PlaybackService"

        /** How long the music takes to go quiet at the end of a sleep timer. */
        private const val SLEEP_FADE_MS = 6_000L
        private const val SLEEP_FADE_STEPS = 60

        /** How often the end-of-track timer looks at the clock. */
        private const val END_WATCH_MS = 200L

        /** How close to its end a song is stopped, before any crossfade. */
        private const val END_STOP_MS = 400L

        /** How close a song has to have been for a change of track to be its end. */
        private const val END_NEAR_MS = 2_500L

        /** One step of a fade through the engine's volume. */
        private const val ENGINE_FADE_STEP_MS = 50L

        /** Maximum upcoming tracks to buffer in queue for autoplay. */
        private const val AUTOPLAY_QUEUE_CAP = 10

        /** How often the position is written back while playing. */
        private const val SAVE_INTERVAL_MS = 10_000L

        /** What the engine reports for an account it cannot stream to. */
        private const val PREMIUM_REQUIRED = "premium account required"

        /** Tells the service a Spotify session now exists. */
        const val ACTION_CONNECT = "dev.lelonio.square.action.CONNECT"

        fun connect(context: android.content.Context) {
            context.startService(
                Intent(context, PlaybackService::class.java).setAction(ACTION_CONNECT),
            )
        }
    }
}

/**
 * The language Spotify should answer in.
 *
 * Read from the resources rather than from the device, so it follows what the
 * app is actually showing: today that is Italian for everyone, and the day it
 * has more languages this keeps pointing at the one in use.
 */
/**
 * The language to ask Spotify to answer in.
 *
 * Read from the app's own setting rather than from this context's resources: a
 * service is not re-created when the language changes, and its configuration
 * would still be yesterday's.
 */
private fun android.content.Context.appLanguage(): String =
    (applicationContext as dev.lelonio.square.SquareApplication).language.language()
